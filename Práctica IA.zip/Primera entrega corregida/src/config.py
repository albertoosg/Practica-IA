
BRANCHES = [{"name": "Branch A", "counters": 2}, {"name": "Branch B", "counters": 2}, {"name": "Branch C", "counters": 2}]
BANK_NAME = "Bank Central"